# Mahakal Tour & Travel — Free Starter Website

Contact / WhatsApp: 9630783154

## Files
- index.html — customer-facing website
- admin.html — trip management page
- style.css — design
- script.js — trip cards + WhatsApp booking

## Important
This starter version uses browser localStorage, so trips added in admin.html are saved only in that browser/device. It is NOT a secure online database/admin system.

For a real multi-device website where only you can log in and manage trips, create a free Firebase project in YOUR Google account and connect Firestore + Firebase Authentication. Then deploy the site on Firebase Hosting or another free host. That keeps ownership in your account.

## Publish free
You can upload these files to a static host such as GitHub Pages, Netlify, or Cloudflare Pages. Keep the repository/account in your own name.

## WhatsApp
The booking buttons already use 9630783154.
